package test;
public class shop_Pojo {
    private int shopid,vid;
    private String shop_name,shop_add,shop_cat,shop_profile,landmark;

    /**
     * @return the shopid
     */
    public int getShopid() {
        return shopid;
    }

    /**
     * @param shopid the shopid to set
     */
    public void setShopid(int shopid) {
        this.shopid = shopid;
    }

    /**
     * @return the vid
     */
    public int getVid() {
        return vid;
    }

    /**
     * @param vid the vid to set
     */
    public void setVid(int vid) {
        this.vid = vid;
    }

    /**
     * @return the shop_name
     */
    public String getShop_name() {
        return shop_name;
    }

    /**
     * @param shop_name the shop_name to set
     */
    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }

    /**
     * @return the shop_add
     */
    public String getShop_add() {
        return shop_add;
    }

    /**
     * @param shop_add the shop_add to set
     */
    public void setShop_add(String shop_add) {
        this.shop_add = shop_add;
    }

    /**
     * @return the shop_cat
     */
    public String getShop_cat() {
        return shop_cat;
    }

    /**
     * @param shop_cat the shop_cat to set
     */
    public void setShop_cat(String shop_cat) {
        this.shop_cat = shop_cat;
    }

    /**
     * @return the shop_profile
     */
    public String getShop_profile() {
        return shop_profile;
    }

    /**
     * @param shop_profile the shop_profile to set
     */
    public void setShop_profile(String shop_profile) {
        this.shop_profile = shop_profile;
    }

    /**
     * @return the landmark
     */
    public String getLandmark() {
        return landmark;
    }

    /**
     * @param landmark the landmark to set
     */
    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }
    
    
}
