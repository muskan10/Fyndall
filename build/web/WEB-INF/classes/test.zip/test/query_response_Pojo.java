package test;

public class query_response_Pojo {
    private int qrsid,qid,uid,vid;
    private String response_time,timestamp;

    /**
     * @return the qrsid
     */
    public int getQrsid() {
        return qrsid;
    }

    /**
     * @param qrsid the qrsid to set
     */
    public void setQrsid(int qrsid) {
        this.qrsid = qrsid;
    }

    /**
     * @return the qid
     */
    public int getQid() {
        return qid;
    }

    /**
     * @param qid the qid to set
     */
    public void setQid(int qid) {
        this.qid = qid;
    }

    /**
     * @return the uid
     */
    public int getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(int uid) {
        this.uid = uid;
    }

    /**
     * @return the vid
     */
    public int getVid() {
        return vid;
    }

    /**
     * @param vid the vid to set
     */
    public void setVid(int vid) {
        this.vid = vid;
    }

    /**
     * @return the response_time
     */
    public String getResponse_time() {
        return response_time;
    }

    /**
     * @param response_time the response_time to set
     */
    public void setResponse_time(String response_time) {
        this.response_time = response_time;
    }

    /**
     * @return the timestamp
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
    
}