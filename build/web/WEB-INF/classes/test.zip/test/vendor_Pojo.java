package test;
public class vendor_Pojo {
    private int vid;
    private String vname,email,vendor_profile,contact,v_pwd;

    /**
     * @return the vid
     */
    public int getVid() {
        return vid;
    }

    /**
     * @param vid the vid to set
     */
    public void setVid(int vid) {
        this.vid = vid;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }

    /**
     * @return the vname
     */
    public String getVname() {
        return vname;
    }

    /**
     * @param vname the vname to set
     */
    public void setVname(String vname) {
        this.vname = vname;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the vendor_profile
     */
    public String getVendor_profile() {
        return vendor_profile;
    }

    /**
     * @param vendor_profile the vendor_profile to set
     */
    public void setVendor_profile(String vendor_profile) {
        this.vendor_profile = vendor_profile;
    }

    /**
     * @return the v_pwd
     */
    public String getV_pwd() {
        return v_pwd;
    }

    /**
     * @param v_pwd the v_pwd to set
     */
    public void setV_pwd(String v_pwd) {
        this.v_pwd = v_pwd;
    }
    
    
}