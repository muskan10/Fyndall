/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author muskan verma
 */
public class Category_Pojo {
   private String cname,cimage;
   private int cid;

    /**
     * @return the cname
     */
    public String getCname() {
        return cname;
    }

    /**
     * @param cname the cname to set
     */
    public void setCname(String cname) {
        this.cname = cname;
    }

    /**
     * @return the cimage
     */
    public String getCimage() {
        return cimage;
    }

    /**
     * @param cimage the cimage to set
     */
    public void setCimage(String cimage) {
        this.cimage = cimage;
    }

    /**
     * @return the cid
     */
    public int getCid() {
        return cid;
    }

    /**
     * @param cid the cid to set
     */
    public void setCid(int cid) {
        this.cid = cid;
    }
    
}
