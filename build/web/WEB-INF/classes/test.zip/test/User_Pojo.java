package test;

public class User_Pojo {
    
    private int uid;
    private String username;
    private String uemailid;
    private String  ucontact;
    private String uprofile;

    /**
     * @return the uid
     */
    public int getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(int uid) {
        this.uid = uid;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the uemailid
     */
    public String getUemailid() {
        return uemailid;
    }

    /**
     * @param uemailid the uemailid to set
     */
    public void setUemailid(String uemailid) {
        this.uemailid = uemailid;
    }

    /**
     * @return the ucontact
     */
    public String getUcontact() {
        return ucontact;
    }

    /**
     * @param ucontact the ucontact to set
     */
    public void setUcontact(String ucontact) {
        this.ucontact = ucontact;
    }

    /**
     * @return the uprofile
     */
    public String getUprofile() {
        return uprofile;
    }

    /**
     * @param uprofile the uprofile to set
     */
    public void setUprofile(String uprofile) {
        this.uprofile = uprofile;
    }

}